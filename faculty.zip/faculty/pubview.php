<?php require_once('Connections/Connections.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_Connections, $Connections);
$query_Recordset1 = "SELECT * FROM publication";
$Recordset1 = mysql_query($query_Recordset1, $Connections) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<table width="100%" border="1">
  <tr>
    <td colspan="6"><div align="center">Administrator's Home Page</div></td>
  </tr>
  <tr>
    <td width="14%"><a href="facview.php">Faculty Profile</a></td>
    <td width="17%"><a href="eduview.php">Education Details</a></td>
    <td width="17%"><a href="pubview.php">Publication Details</a></td>
    <td width="17%"><a href="projview.php">Project Guidance</a></td>
    <td width="17%"><a href="memview.php">Membership</a></td>
    <td width="18%"><a href="<?php echo $logoutAction ?>">Logout</a></td>
  </tr>
</table>
<p align="center">FACULTIES PAPER PUBLICATION DETAILS</p>
<table border="1">
  <tr>
    <td>Faculty Name`</td>
    <td>Faculty ID</td>
    <td>Author Position</td>
    <td>Author Name</td>
    <td>Title</td>
    <td>Journal Name</td>
    <td>Volume</td>
    <td>Issue</td>
    <td>Year of Publication</td>
    <td>ISBN</td>
    <td>Index Type</td>
    <td>Publication Link</td>
  </tr>
  <?php do { ?>
    <tr>
      <td><?php echo $row_Recordset1['facname']; ?></td>
      <td><?php echo $row_Recordset1['facid']; ?></td>
      <td><?php echo $row_Recordset1['authorposition']; ?></td>
      <td><?php echo $row_Recordset1['authorname']; ?></td>
      <td><?php echo $row_Recordset1['title']; ?></td>
      <td><?php echo $row_Recordset1['journalname']; ?></td>
      <td><?php echo $row_Recordset1['volume']; ?></td>
      <td><?php echo $row_Recordset1['issue']; ?></td>
      <td><?php echo $row_Recordset1['yearpubl']; ?></td>
      <td><?php echo $row_Recordset1['isbn']; ?></td>
      <td><?php echo $row_Recordset1['indextype']; ?></td>
      <td><?php echo $row_Recordset1['publink']; ?></td>
    </tr>
    <?php } while ($row_Recordset1 = mysql_fetch_assoc($Recordset1)); ?>
</table>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
