<?php require_once('Connections/Connections.php'); ?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "step2")) {
  $insertSQL = sprintf("INSERT INTO education (facname, facid, degree, branch, institute, university, percentage, yearofpass, `mode`, totalexperience, prevexperience, mcetexperience, teaching, industry) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_SESSION['FacName'], "text"),
                       GetSQLValueString($_SESSION['FacId'], "text"),
                       GetSQLValueString($_POST['degree'], "text"),
                       GetSQLValueString($_POST['branch'], "text"),
                       GetSQLValueString($_POST['institute'], "text"),
                       GetSQLValueString($_POST['university'], "text"),
                       GetSQLValueString($_POST['percentage'], "text"),
                       GetSQLValueString($_POST['yearofpass'], "text"),
                       GetSQLValueString($_POST['mode'], "text"),
                       GetSQLValueString($_POST['totalexperience'], "text"),
                       GetSQLValueString($_POST['prevexperience'], "text"),
                       GetSQLValueString($_POST['mcetexperience'], "text"),
                       GetSQLValueString($_POST['teaching'], "text"),
                       GetSQLValueString($_POST['industry'], "text"));

  mysql_select_db($database_Connections, $Connections);
  $Result1 = mysql_query($insertSQL, $Connections) or die(mysql_error());
  
  $insertGoTo = "step3.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
  
}
?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Hello, world!</title>
</head>

<body>
    <section class="vh-300" style="background-color: #eee;">
        <div class="container h-100">
            <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col-lg-12 col-xl-11">
                    <div class="card text-black" style="border-radius: 25px;">
                        <div class="card-body p-md-5">
                            <div class="row justify-content-center">
                                <div class="col-md-10 col-lg-6 col-xl-5 order-2 order-lg-1">

                                    <p class="text-center h1 fw-bold mb-5 mx-1 mx-md-4 mt-4">EDUCATION</p>

                                    <form method="POST" action="<?php echo $editFormAction; ?>" class="mx-1 mx-md-4" name="step2">

                                        <div class="d-flex flex-row align-items-center mb-4">
                                            <i class="fas fa-envelope fa-lg me-3 fa-fw"></i>
                                            <div class="form-outline flex-fill mb-0">
                                                <input name="degree" type="text" class="form-control" id="form3Example1c"
                                                    placeholder="Degree" />

                                            </div>
                                        </div>
                                        <div class="d-flex flex-row align-items-center mb-4">
                                            <i class="fas fa-envelope fa-lg me-3 fa-fw"></i>
                                            <div class="form-outline flex-fill mb-0">
                                                <input name="branch" type="text"
                                                    class="form-control form-control-md" id="branch" placeholder="Branch/Specialization" 
                                                >
                                            </div>
                                        </div>

                                        <div class="d-flex flex-row align-items-center mb-4">
                                            <i class="fas fa-envelope fa-lg me-3 fa-fw"></i>
                                            <div class="form-outline flex-fill mb-0">
                                                <input name="institute" type="text"
                                                    class="form-control form-control-md" id="institute" placeholder="Institute Location" >
                                            </div>
                                        </div>
                                        <div class="d-flex flex-row align-items-center mb-4">
                                            <i class="fas fa-envelope fa-lg me-3 fa-fw"></i>
                                            <div class="form-outline flex-fill mb-0">
                                                <input name="university" type="text"
                                                    class="form-control form-control-md" id="university" placeholder="University">
                                            </div>
                                        </div>
                                        
                                        <div class="d-flex flex-row align-items-center mb-4">
                                            <i class="fas fa-envelope fa-lg me-3 fa-fw"></i>
                                            <div class="form-outline flex-fill mb-0">
                                                <input name="percentage" type="text"
                                                    class="form-control form-control-md" id="percentage" placeholder="Percentage" 
                                                    >
                                            </div>
                                        </div>
                                        <div class="d-flex flex-row align-items-center mb-4">
                                            <i class="fas fa-envelope fa-lg me-3 fa-fw"></i>
                                            <div class="form-outline flex-fill mb-0">
                                                <input name="yearofpass" type="text"
                                                    required
                                                    class="form-control form-control-md" id="yearofpass" placeholder="year of pass" onfocus="(this.type='date')">
                                            </div>
                                        </div>
                                        <div class="d-flex flex-row align-items-center mb-4">
                                            <i class="fas fa-envelope fa-lg me-3 fa-fw"></i>
                                            <div class="form-outline flex-fill mb-0">
                                               <label>mode:</label>
                                               <input  style="margin-left: 80px;"type="radio" value="online" name="mode"><label>Online</label>
                                               <input  style="margin-left: 50px;" type="radio" value="offline" name="mode"><label>Offline</label>
                                            </div>
                                        </div>
                                        <p class="text-center h1 fw-bold mb-5 mx-1 mx-md-4 mt-4">EXPERIENCE</p>
                                        <div class="d-flex flex-row align-items-center mb-4">
                                            <i class="fas fa-envelope fa-lg me-3 fa-fw"></i>
                                            <div class="form-outline flex-fill mb-0">
                                                <input name="totalexperience" type="text" class="form-control" id="form3Example1c"
                                                    placeholder="Total experience" />

                                            </div>
                                        </div>
                                        <div class="d-flex flex-row align-items-center mb-4">
                                            <i class="fas fa-envelope fa-lg me-3 fa-fw"></i>
                                            <div class="form-outline flex-fill mb-0">
                                                <input name="prevexperience" type="text" class="form-control" id="form3Example1c"
                                                    placeholder="Previous experience(if any)" />

                                            </div>
                                        </div>
                                        <div class="d-flex flex-row align-items-center mb-4">
                                            <i class="fas fa-envelope fa-lg me-3 fa-fw"></i>
                                            <div class="form-outline flex-fill mb-0">
                                                <input name="mcetexperience" type="text" class="form-control" id="form3Example1c"
                                                    placeholder="Mcet experience" />

                                            </div>
                                        </div>
                                        <div class="d-flex flex-row align-items-center mb-4">
                                            <i class="fas fa-envelope fa-lg me-3 fa-fw"></i>
                                            <div class="form-outline flex-fill mb-0">
                                                <input name="teaching" type="text" class="form-control" id="form3Example1c"
                                                    placeholder="Teaching experience" />

                                            </div>
                                        </div>
                                        <div class="d-flex flex-row align-items-center mb-4">
                                            <i class="fas fa-envelope fa-lg me-3 fa-fw"></i>
                                            <div class="form-outline flex-fill mb-0">
                                                <input name="industry" type="text" class="form-control" id="form3Example1c"
                                                    placeholder="Industry experience(if any)" />

                                            </div>
                                        </div>
                                       


                                        <div class="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
                                            <input name="submit" type="submit" value="Step 3 &gt;&gt;">
                                        </div>
                                        <input type="hidden" name="MM_insert" value="step2">

                                    </form>

                                </div>
                             
                            </div>
                        
                        </div>
                
                        
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
        crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
</body>

</html>