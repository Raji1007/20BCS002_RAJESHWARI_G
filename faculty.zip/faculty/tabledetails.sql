create table facultyinfo (facname varchar(30), facid varchar(15), fdob varchar(10), age varchar(10), address varchar(100), gender varchar(12), department varchar(10), joindate varchar(10), panno varchar(20), aadharno varchar(15), prodate varchar(10), emailid varchar(30), password varchar(30))


create table education (degree varchar(30), branch varchar(30), institute varchar(30), university varchar(50), percentage varchar(10), yearofpass varchar(10), mode varchar(10), totalexperience varchar(10), prevexperience varchar(20), mcetexperience varchar(20), teaching varchar(20), industry varchar(20))


create table publication (authorposition varchar(30), authorname varchar(30), title varchar(100), journalname varchar(20), volume varchar(20), issue varchar(10), yearpubl varchar(10), isbn varchar(20), indextype varchar(10), publink varchar(200))

create table projectguide (academicyear varchar (20), branch varchar(20), semester varchar(5), titleproj varchar(50), totalstudent varchar(5), company varchar(30), projtime varchar(10), contactinfo varchar(20))

create table membership (eventtype varchar(20), eventname varchar(30), membershiptype varchar(30), role varchar(20), duration varchar(20))

create table adminlogin (adminid varchar(10), adminpass varchar(10))