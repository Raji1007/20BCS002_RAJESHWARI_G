<?php require_once('Connections/Connections.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_RsSelectFacultyInfo = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_RsSelectFacultyInfo = $_SESSION['MM_Username'];
}
mysql_select_db($database_Connections, $Connections);
$query_RsSelectFacultyInfo = sprintf("SELECT * FROM facultyinfo WHERE facid = %s", GetSQLValueString($colname_RsSelectFacultyInfo, "text"));
$RsSelectFacultyInfo = mysql_query($query_RsSelectFacultyInfo, $Connections) or die(mysql_error());
$row_RsSelectFacultyInfo = mysql_fetch_assoc($RsSelectFacultyInfo);
$totalRows_RsSelectFacultyInfo = mysql_num_rows($RsSelectFacultyInfo);

$colname_RsSelectEducation = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_RsSelectEducation = $_SESSION['MM_Username'];
}
mysql_select_db($database_Connections, $Connections);
$query_RsSelectEducation = sprintf("SELECT * FROM education WHERE facid = %s", GetSQLValueString($colname_RsSelectEducation, "text"));
$RsSelectEducation = mysql_query($query_RsSelectEducation, $Connections) or die(mysql_error());
$row_RsSelectEducation = mysql_fetch_assoc($RsSelectEducation);
$totalRows_RsSelectEducation = mysql_num_rows($RsSelectEducation);
?>
<!doctype html>
                        <html>
                            <head>
                                <meta charset='utf-8'>
                                <meta name='viewport' content='width=device-width, initial-scale=1'>
                                <title>Snippet - BBBootstrap</title>
                                <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css' rel='stylesheet'>
                                <link href='' rel='stylesheet'>
                                <script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>
                                <style>body {
                                 background-color: #8ca6f4;
}

.form-control:focus {
    box-shadow: none;
    border-color: #000d37
}

.profile-button {
    background: rgb(50, 39, 120);
    box-shadow: none;
    border: none
}

.profile-button:hover {
    background: #682773
}

.profile-button:focus {
    background: #682773;
    box-shadow: none
}

.profile-button:active {
    background: #682773;
    box-shadow: none
}

.back:hover {
    color: #682773;
    cursor: pointer
}

.labels {
    font-size: 11px
}

.add-experience:hover {
    background: #8ca6f4;
    color: #fff;
    cursor: pointer;
    border: solid 1px white
}</style>
                                </head>
                                <!-- <body oncontextmenu='return false' class='snippet-body'> -->
                                <div class="container rounded bg-white mt-5 mb-5">
    <div class="row">
        <div class="col-md-3 border-right">
            <div class="d-flex flex-column align-items-center text-center p-3 py-5"><img class="rounded-circle mt-5" width="150px" src="https://st3.depositphotos.com/15648834/17930/v/600/depositphotos_179308454-stock-illustration-unknown-person-silhouette-glasses-profile.jpg"><span class="font-weight-bold"><?php echo $row_RsSelectFacultyInfo['facname']; ?></span><span class="text-black-50"><?php echo $row_RsSelectFacultyInfo['emailid']; ?></span><span> </span></div>
        </div>
        <div class="col-md-5 border-right">
            <div class="p-3 py-5">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 class="text-right">Profile Settings</h4>
                </div>
                <div class="row mt-2">
                    <div class="col-md-12"><label class="labels">Name</label><input type="text" class="form-control" placeholder="first name" value="<?php echo $row_RsSelectFacultyInfo['facname']; ?>"></div>

              </div>
                <div class="row mt-3">
                    <div class="col-md-12"><label class="labels">ID</label><input type="text" class="form-control" placeholder="ID" value="<?php echo $row_RsSelectFacultyInfo['facid']; ?>"></div>
                    <div class="col-md-12"><label class="labels">DOB</label><input type="date" class="form-control" placeholder="DOB" value="<?php echo $row_RsSelectFacultyInfo['fdob']; ?>"></div>
                    <div class="col-md-12"><label class="labels">Age</label><input type="text" class="form-control" placeholder="Age" value="<?php echo $row_RsSelectFacultyInfo['age']; ?>"></div>
                    <div class="col-md-12"><label class="labels">Address</label><input type="text" class="form-control" placeholder="enter address line" value="<?php echo $row_RsSelectFacultyInfo['address']; ?>"></div>
                    <div class="col-md-12"><label class="labels">Gender</label><input type="text" class="form-control" placeholder="Gender" value="<?php echo $row_RsSelectFacultyInfo['gender']; ?>"></div>
                    <div class="col-md-12"><label class="labels">join date</label><input type="text" class="form-control" placeholder="date" value="<?php echo $row_RsSelectFacultyInfo['joindate']; ?>"></div>
                    <div class="col-md-12"><label class="labels">pan no</label><input type="text" class="form-control" placeholder="pan no" value="<?php echo $row_RsSelectFacultyInfo['panno']; ?>"></div>
                    <div class="col-md-12"><label class="labels">Email ID</label><input type="text" class="form-control" placeholder=" email id" value="<?php echo $row_RsSelectFacultyInfo['emailid']; ?>"></div>
                    <div class="col-md-12"><label class="labels">Education</label><input type="text" class="form-control" placeholder="degree" value="<?php echo $row_RsSelectEducation['degree']; ?>"></div>
                    <div class="col-md-12"><label class="labels">Branch/Specialization </label><input type="text" class="form-control" placeholder="Branch/Specialization" value="<?php echo $row_RsSelectEducation['branch']; ?>"></div>
                    <div class="col-md-12"><label class="labels">Institute Location</label><input type="text" class="form-control" placeholder="Institute Location" value="<?php echo $row_RsSelectEducation['institute']; ?>"></div>
                    <div class="col-md-12"><label class="labels">University</label><input type="text" class="form-control" placeholder="University" value="<?php echo $row_RsSelectEducation['university']; ?>"></div>
                    <div class="col-md-12"><label class="labels">Percentage</label><input type="number" class="form-control" placeholder="Percentage" value="<?php echo $row_RsSelectEducation['percentage']; ?>"></div>
                    <div class="col-md-12"><label class="labels">Year of Pass</label><input type="date" class="form-control" placeholder="Year of Pass" value="<?php echo $row_RsSelectEducation['yearofpass']; ?>"></div>            
                   
                </div>
                <div class="row mt-0">
                    <div class="col-md-0"><label class="labels">Mode<input type="text" class="form-control" placeholder="Online/Offline" value="<?php echo $row_RsSelectEducation['mode']; ?>"></div>
                   
                </div>
              <div class="mt-5 text-center"><button class="btn btn-primary profile-button" type="button">Save Profile</button></div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="p-3 py-5">
                <div class="d-flex justify-content-between align-items-center experience"><span>Experience</span><span class="border px-3 p-1 add-experience"><i class="fa fa-plus"></i>&nbsp;<a href="<?php echo $logoutAction ?>">Logout</a></span></div><br>
                <div class="col-md-12"><label class="labels">Total Experience</label><input type="text" class="form-control" placeholder="experience" value="<?php echo $row_RsSelectEducation['totalexperience']; ?>"></div> <br>
                <div class="col-md-12"><label class="labels">Previous Experience</label><input type="text" class="form-control" placeholder="experience" value="<?php echo $row_RsSelectEducation['prevexperience']; ?>"></div> <br>
                <div class="col-md-12"><label class="labels">MCET Experience</label><input type="text" class="form-control" placeholder="experience" value="<?php echo $row_RsSelectEducation['mcetexperience']; ?>"></div> <br>
                <div class="col-md-12"><label class="labels">Teaching Experience</label><input type="text" class="form-control" placeholder="experience" value="<?php echo $row_RsSelectEducation['teaching']; ?>"></div> <br>
                <div class="col-md-12"><label class="labels">Industry Experience</label><input type="text" class="form-control" placeholder="experience" value="<?php echo $row_RsSelectEducation['industry']; ?>"></div> <br>
                <div class="col-md-12"><label class="labels">Additional Details</label><input type="text" class="form-control" placeholder="additional details" value=""></div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
                                <script type='text/javascript' src='https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js'></script>
                                <script type='text/javascript' src=''></script>
                                <script type='text/javascript' src=''></script>
                                <script type='text/Javascript'></script>
                                </body>
                            </html>
                        <?php
mysql_free_result($RsSelectFacultyInfo);

mysql_free_result($RsSelectEducation);
?>
