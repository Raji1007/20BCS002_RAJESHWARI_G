-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 12, 2022 at 12:59 PM
-- Server version: 5.6.25
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `faculty`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminlogin`
--

CREATE TABLE IF NOT EXISTS `adminlogin` (
  `adminsno` int(7) NOT NULL,
  `adminid` varchar(10) DEFAULT NULL,
  `adminpass` varchar(10) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminlogin`
--

INSERT INTO `adminlogin` (`adminsno`, `adminid`, `adminpass`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `education`
--

CREATE TABLE IF NOT EXISTS `education` (
  `facname` varchar(30) DEFAULT NULL,
  `facid` varchar(15) NOT NULL DEFAULT '',
  `degree` varchar(30) DEFAULT NULL,
  `branch` varchar(30) DEFAULT NULL,
  `institute` varchar(30) DEFAULT NULL,
  `university` varchar(50) DEFAULT NULL,
  `percentage` varchar(10) DEFAULT NULL,
  `yearofpass` varchar(10) DEFAULT NULL,
  `mode` varchar(10) DEFAULT NULL,
  `totalexperience` varchar(10) DEFAULT NULL,
  `prevexperience` varchar(20) DEFAULT NULL,
  `mcetexperience` varchar(20) DEFAULT NULL,
  `teaching` varchar(20) DEFAULT NULL,
  `industry` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `education`
--

INSERT INTO `education` (`facname`, `facid`, `degree`, `branch`, `institute`, `university`, `percentage`, `yearofpass`, `mode`, `totalexperience`, `prevexperience`, `mcetexperience`, `teaching`, `industry`) VALUES
('Nobel Marry', 'FAC002`', 'ME', 'CSE', 'DrMCET', 'Anna', '98.7', '2004-10-10', 'offline', '8 years', 'NIL', '8 Years', '7 Years', '1 year');

-- --------------------------------------------------------

--
-- Table structure for table `facultyinfo`
--

CREATE TABLE IF NOT EXISTS `facultyinfo` (
  `facname` varchar(30) DEFAULT NULL,
  `facid` varchar(15) NOT NULL DEFAULT '',
  `fdob` varchar(10) DEFAULT NULL,
  `age` varchar(10) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `gender` varchar(12) DEFAULT NULL,
  `department` varchar(10) DEFAULT NULL,
  `joindate` varchar(10) DEFAULT NULL,
  `panno` varchar(20) DEFAULT NULL,
  `aadharno` varchar(15) DEFAULT NULL,
  `prodate` varchar(10) DEFAULT NULL,
  `emailid` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `facultyinfo`
--

INSERT INTO `facultyinfo` (`facname`, `facid`, `fdob`, `age`, `address`, `gender`, `department`, `joindate`, `panno`, `aadharno`, `prodate`, `emailid`, `password`) VALUES
('Nobel Marry', 'FAC002`', '1980-10-10', '43', '34, Palakkad Road, Pollachi', 'female', 'male', '2015-05-04', 'AXBP4984A43', '3938282929', '2020-10-10', 'marry@gmail.com', 'FAC002`');

-- --------------------------------------------------------

--
-- Table structure for table `membership`
--

CREATE TABLE IF NOT EXISTS `membership` (
  `facname` varchar(30) DEFAULT NULL,
  `facid` varchar(15) NOT NULL DEFAULT '',
  `eventtype` varchar(20) DEFAULT NULL,
  `eventname` varchar(30) DEFAULT NULL,
  `membershiptype` varchar(30) DEFAULT NULL,
  `role` varchar(20) DEFAULT NULL,
  `duration` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `membership`
--

INSERT INTO `membership` (`facname`, `facid`, `eventtype`, `eventname`, `membershiptype`, `role`, `duration`) VALUES
('Nobel Marry', 'FAC002`', 'IEE Explorer', 'Seminar', 'Perminent', 'Analyst', '05:27');

-- --------------------------------------------------------

--
-- Table structure for table `projectguide`
--

CREATE TABLE IF NOT EXISTS `projectguide` (
  `facname` varchar(30) DEFAULT NULL,
  `facid` varchar(15) NOT NULL DEFAULT '',
  `academicyear` varchar(20) DEFAULT NULL,
  `branch` varchar(20) DEFAULT NULL,
  `semester` varchar(5) DEFAULT NULL,
  `titleproj` varchar(50) DEFAULT NULL,
  `totalstudent` varchar(5) DEFAULT NULL,
  `company` varchar(30) DEFAULT NULL,
  `projtime` varchar(10) DEFAULT NULL,
  `contactinfo` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `projectguide`
--

INSERT INTO `projectguide` (`facname`, `facid`, `academicyear`, `branch`, `semester`, `titleproj`, `totalstudent`, `company`, `projtime`, `contactinfo`) VALUES
('Nobel Marry', 'FAC002`', '2022-23', 'CSE', 'VII', 'Steganography', '4', 'NIL', '05:27', 'NIL');

-- --------------------------------------------------------

--
-- Table structure for table `publication`
--

CREATE TABLE IF NOT EXISTS `publication` (
  `facname` varchar(30) DEFAULT NULL,
  `facid` varchar(15) NOT NULL DEFAULT '',
  `authorposition` varchar(30) DEFAULT NULL,
  `authorname` varchar(30) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `journalname` varchar(20) DEFAULT NULL,
  `volume` varchar(20) DEFAULT NULL,
  `issue` varchar(10) DEFAULT NULL,
  `yearpubl` varchar(10) DEFAULT NULL,
  `isbn` varchar(20) DEFAULT NULL,
  `indextype` varchar(10) DEFAULT NULL,
  `publink` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `publication`
--

INSERT INTO `publication` (`facname`, `facid`, `authorposition`, `authorname`, `title`, `journalname`, `volume`, `issue`, `yearpubl`, `isbn`, `indextype`, `publink`) VALUES
('Nobel Marry', 'FAC002`', 'First', 'Nobel Marry', 'Matrix Dimenality Reduction', 'IJERT', '1', '1', '2010-10-10', '38-34980', 'Scopus', 'http://www.ijert.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminlogin`
--
ALTER TABLE `adminlogin`
  ADD PRIMARY KEY (`adminsno`);

--
-- Indexes for table `education`
--
ALTER TABLE `education`
  ADD PRIMARY KEY (`facid`);

--
-- Indexes for table `facultyinfo`
--
ALTER TABLE `facultyinfo`
  ADD PRIMARY KEY (`facid`);

--
-- Indexes for table `membership`
--
ALTER TABLE `membership`
  ADD PRIMARY KEY (`facid`);

--
-- Indexes for table `projectguide`
--
ALTER TABLE `projectguide`
  ADD PRIMARY KEY (`facid`);

--
-- Indexes for table `publication`
--
ALTER TABLE `publication`
  ADD PRIMARY KEY (`facid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminlogin`
--
ALTER TABLE `adminlogin`
  MODIFY `adminsno` int(7) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
