<?php require_once('Connections/Connections.php'); ?>
<?php
//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

// ** Logout the current user. **
$logoutAction = $_SERVER['PHP_SELF']."?doLogout=true";
if ((isset($_SERVER['QUERY_STRING'])) && ($_SERVER['QUERY_STRING'] != "")){
  $logoutAction .="&". htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_GET['doLogout'])) &&($_GET['doLogout']=="true")){
  //to fully log out a visitor we need to clear the session varialbles
  $_SESSION['MM_Username'] = NULL;
  $_SESSION['MM_UserGroup'] = NULL;
  $_SESSION['PrevUrl'] = NULL;
  unset($_SESSION['MM_Username']);
  unset($_SESSION['MM_UserGroup']);
  unset($_SESSION['PrevUrl']);
	
  $logoutGoTo = "index.php";
  if ($logoutGoTo) {
    header("Location: $logoutGoTo");
    exit;
  }
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_Connections, $Connections);
$query_Recordset1 = "SELECT * FROM education";
$Recordset1 = mysql_query($query_Recordset1, $Connections) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<table width="100%" border="1">
  <tr>
    <td colspan="6"><div align="center">Administrator's Home Page</div></td>
  </tr>
  <tr>
    <td width="14%"><a href="facview.php">Faculty Profile</a></td>
    <td width="17%"><a href="eduview.php">Education Details</a></td>
    <td width="17%"><a href="pubview.php">Publication Details</a></td>
    <td width="17%"><a href="projview.php">Project Guidance</a></td>
    <td width="17%"><a href="memview.php">Membership</a></td>
    <td width="18%"><a href="<?php echo $logoutAction ?>">Logout</a></td>
  </tr>
</table>
<p align="center">EDUCATIONAL QUALIFICATION OF THE FACULTIES</p>
<table border="1">
  <tr>
    <td>facname</td>
    <td>facid</td>
    <td>degree</td>
    <td>branch</td>
    <td>institute</td>
    <td>university</td>
    <td>percentage</td>
    <td>yearofpass</td>
    <td>mode</td>
    <td>totalexperience</td>
    <td>prevexperience</td>
    <td>mcetexperience</td>
    <td>teaching</td>
    <td>industry</td>
  </tr>
  <?php do { ?>
    <tr>
      <td><?php echo $row_Recordset1['facname']; ?></td>
      <td><?php echo $row_Recordset1['facid']; ?></td>
      <td><?php echo $row_Recordset1['degree']; ?></td>
      <td><?php echo $row_Recordset1['branch']; ?></td>
      <td><?php echo $row_Recordset1['institute']; ?></td>
      <td><?php echo $row_Recordset1['university']; ?></td>
      <td><?php echo $row_Recordset1['percentage']; ?></td>
      <td><?php echo $row_Recordset1['yearofpass']; ?></td>
      <td><?php echo $row_Recordset1['mode']; ?></td>
      <td><?php echo $row_Recordset1['totalexperience']; ?></td>
      <td><?php echo $row_Recordset1['prevexperience']; ?></td>
      <td><?php echo $row_Recordset1['mcetexperience']; ?></td>
      <td><?php echo $row_Recordset1['teaching']; ?></td>
      <td><?php echo $row_Recordset1['industry']; ?></td>
    </tr>
    <?php } while ($row_Recordset1 = mysql_fetch_assoc($Recordset1)); ?>
</table>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
